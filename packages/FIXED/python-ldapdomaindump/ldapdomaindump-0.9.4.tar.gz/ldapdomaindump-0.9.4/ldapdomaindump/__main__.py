#!/usr/bin/env python
import ldapdomaindump
ldapdomaindump.main()
